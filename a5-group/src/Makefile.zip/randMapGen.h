#ifndef RANDMAPGEN_H
#define RANDMAPGEN_H

#include <string>

std::string randMap();

#endif
